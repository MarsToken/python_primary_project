# -*-coding:utf-8 -*-
# Author:王茂波
def test():
    print('---test---')


def test1():
    print('--test1--')
