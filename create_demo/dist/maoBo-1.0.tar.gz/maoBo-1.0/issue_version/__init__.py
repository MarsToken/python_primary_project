# -*-coding:utf-8 -*-
# Author:王茂波
__all__ = ['Module1']
# python2
# import Module1
# p2 p3通用 .表示当前路径
from . import Module1
