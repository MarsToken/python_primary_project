# -*-coding:utf-8 -*-
# Author:王茂波
def module2():
    print('module2---------')
