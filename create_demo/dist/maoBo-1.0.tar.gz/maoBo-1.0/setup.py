# -*-coding:utf-8 -*-
# Author:王茂波
# function='打包'
from distutils.core import setup

setup(name="maoBo", version="1.0", description="maoBo's module", author="maoBo",
      py_modules=['issue_version.Module1', 'issue_version.Module2'], platforms='pycharm')
